document.addEventListener("DOMContentLoaded", async () => {
  const data = await chrome.storage.local.get(["api_base", "api_secret"]);
  document.getElementById("base").value = data.api_base || "";
  document.getElementById("secret").value = data.api_secret || "";

  document.getElementById("save").onclick = async () => {
    const base = document.getElementById("base").value.replace(/\/+$/, "");
    const secret = document.getElementById("secret").value;
    const statusEl = document.getElementById("status");

    await chrome.storage.local.set({ api_base: base, api_secret: secret });

    statusEl.textContent = "Проверяю подключение…";
    statusEl.className = "status";

    try {
      const res = await fetch(`${base}/api/personas`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const personas = await res.json();
      statusEl.textContent = `✓ Подключено! ${personas.length} персон в библиотеке.`;
      statusEl.className = "status ok";
    } catch (e) {
      statusEl.textContent = `✗ Ошибка: ${e.message}`;
      statusEl.className = "status err";
    }
  };
});
