// ══════════════════════════════════════
// PersonaHub Chrome Extension - Background Service Worker
// ══════════════════════════════════════

// ── Context Menu Setup ──
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "ph-opinion",
    title: "🗣 Спросить мнение персоны",
    contexts: ["selection"]
  });
  chrome.contextMenus.create({
    id: "ph-clip",
    title: "📎 Сохранить цитату к персоне",
    contexts: ["selection"]
  });
});

// ── Handle Context Menu Clicks ──
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const selectedText = info.selectionText;
  if (!selectedText || !tab?.id) return;

  const actionType = info.menuItemId === "ph-opinion" ? "opinion" : "clip";

  // Store pending action
  await chrome.storage.local.set({
    pendingAction: {
      type: actionType,
      text: selectedText,
      url: tab.url || "",
      pageTitle: tab.title || ""
    }
  });

  // Inject the persona selector panel into the page
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: injectPersonaPanel,
    args: [actionType, selectedText]
  });
});

// ── Listen for messages from injected script ──
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "ph-get-config") {
    chrome.storage.local.get(["api_base", "api_secret"], (data) => {
      sendResponse(data);
    });
    return true; // keep channel open for async
  }

  if (msg.type === "ph-get-personas") {
    chrome.storage.local.get(["api_base"], async (data) => {
      try {
        const res = await fetch(`${data.api_base}/api/personas`);
        const personas = await res.json();
        sendResponse({ ok: true, personas });
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
    });
    return true;
  }

  if (msg.type === "ph-opinion") {
    chrome.storage.local.get(["api_base", "api_secret"], async (data) => {
      try {
        const res = await fetch(`${data.api_base}/api/personas/${msg.personaId}/opinion`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${data.api_secret}`
          },
          body: JSON.stringify({
            type: "opinion",
            sourceUrl: msg.sourceUrl,
            sourceText: msg.sourceText
          })
        });
        const result = await res.json();
        sendResponse({ ok: true, reply: result.reply });
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
    });
    return true;
  }

  if (msg.type === "ph-clip") {
    chrome.storage.local.get(["api_base", "api_secret"], async (data) => {
      try {
        await fetch(`${data.api_base}/api/personas/${msg.personaId}/notes`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${data.api_secret}`
          },
          body: JSON.stringify({
            type: "clip",
            personaId: msg.personaId,
            sourceUrl: msg.sourceUrl,
            sourceText: msg.sourceText
          })
        });
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
    });
    return true;
  }
});

// ══════════════════════════════════════
// Injected function — runs IN the webpage
// ══════════════════════════════════════
function injectPersonaPanel(actionType, selectedText) {
  // Remove existing panel
  const old = document.getElementById("ph-panel");
  if (old) old.remove();

  // Create panel
  const panel = document.createElement("div");
  panel.id = "ph-panel";
  panel.style.cssText = `
    position:fixed; top:0; right:0; width:360px; height:100vh;
    background:#F8F7F4; box-shadow:-4px 0 24px rgba(0,0,0,0.12);
    z-index:2147483647; font-family:'Segoe UI',system-ui,sans-serif;
    overflow-y:auto; transition:transform 0.25s ease;
    border-left:1px solid #E6E3DC;
  `;

  const title = actionType === "opinion" ? "🗣 Спросить мнение" : "📎 Сохранить к персоне";
  const preview = selectedText.length > 120 ? selectedText.slice(0, 120) + "…" : selectedText;

  panel.innerHTML = `
    <div style="padding:20px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
        <div style="font-size:16px;font-weight:700;color:#1A1A1A">${title}</div>
        <button id="ph-close" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9E9890;padding:4px">✕</button>
      </div>
      <div style="background:white;border:1px solid rgba(0,0,0,0.06);border-radius:12px;padding:12px 14px;margin-bottom:16px;font-size:12.5px;color:#6B6560;line-height:1.5;font-style:italic">
        "${preview}"
      </div>
      <div style="font-size:12px;font-weight:600;color:#9E9890;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px">Выберите персону:</div>
      <div id="ph-persona-list" style="font-size:13px;color:#6B6560">Загрузка…</div>
    </div>
  `;
  document.body.appendChild(panel);

  document.getElementById("ph-close").onclick = () => panel.remove();

  // Fetch personas via background script
  chrome.runtime.sendMessage({ type: "ph-get-personas" }, (res) => {
    const container = document.getElementById("ph-persona-list");
    if (!container) return;

    if (!res || !res.ok) {
      container.innerHTML = `<div style="color:#D4380D;font-size:12px;padding:12px;background:white;border-radius:10px">
        ⚠ Не удалось загрузить персоны.<br>Проверьте настройки расширения (клик на иконку).
        ${res?.error ? `<br><small>${res.error}</small>` : ''}
      </div>`;
      return;
    }

    container.innerHTML = res.personas.map(p => `
      <div class="ph-card" data-id="${p.id}" data-name="${p.name}" style="
        display:flex;align-items:center;gap:12px;padding:14px;margin-bottom:6px;
        background:white;border:1px solid rgba(0,0,0,0.06);border-radius:12px;
        cursor:pointer;transition:all 0.15s;
      ">
        <div style="width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg,#EFF6FF,#F5F3FF);
          display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#1D4ED8;flex-shrink:0">
          ${p.name.split(' ').map(w => w[0]).join('').slice(0,2)}
        </div>
        <div style="flex:1;min-width:0">
          <div style="font-size:13.5px;font-weight:600;color:#1A1A1A">${p.name}</div>
          <div style="font-size:11.5px;color:#9E9890;margin-top:1px">${p.role} · ${p.company}</div>
        </div>
        <div style="color:#E6E3DC;font-size:16px">›</div>
      </div>
    `).join("");

    // Bind clicks
    container.querySelectorAll(".ph-card").forEach(card => {
      card.onmouseover = () => { card.style.borderColor = "#D4380D"; card.style.transform = "translateY(-1px)"; };
      card.onmouseout = () => { card.style.borderColor = "rgba(0,0,0,0.06)"; card.style.transform = "none"; };

      card.onclick = () => {
        const pid = card.dataset.id;
        const pname = card.dataset.name;

        // Show loading state
        card.innerHTML = `<div style="padding:4px;color:#D4380D;font-size:12px">⏳ ${actionType === 'opinion' ? 'Генерирую мнение…' : 'Сохраняю…'}</div>`;

        if (actionType === "opinion") {
          chrome.runtime.sendMessage({
            type: "ph-opinion",
            personaId: pid,
            sourceText: selectedText,
            sourceUrl: window.location.href
          }, (res) => {
            if (res?.ok) {
              card.innerHTML = `
                <div style="padding:4px">
                  <div style="font-size:12px;font-weight:600;color:#1A1A1A;margin-bottom:6px">${pname}:</div>
                  <div style="font-size:12.5px;color:#6B6560;line-height:1.55">${res.reply}</div>
                  <div style="font-size:11px;color:#15803D;margin-top:8px;font-weight:600">✓ Сохранено в досье</div>
                </div>`;
              card.style.borderColor = "#15803D";
            } else {
              card.innerHTML = `<div style="color:#D4380D;font-size:12px">⚠ Ошибка: ${res?.error || 'unknown'}</div>`;
            }
          });
        } else {
          chrome.runtime.sendMessage({
            type: "ph-clip",
            personaId: pid,
            sourceText: selectedText,
            sourceUrl: window.location.href
          }, (res) => {
            if (res?.ok) {
              card.innerHTML = `<div style="padding:4px;font-size:12px;color:#15803D;font-weight:600">✓ Цитата сохранена к ${pname}</div>`;
              card.style.borderColor = "#15803D";
            } else {
              card.innerHTML = `<div style="color:#D4380D;font-size:12px">⚠ Ошибка</div>`;
            }
          });
        }
      };
    });
  });
}
